import os
import json

def findFiles(path):
    tmp = []
    for filename in os.listdir(path):
        if '.json' in filename:
            tmp.append(filename)
    return tmp

def calC2(path):
    with open(f'{path}','r',encoding='utf-8') as f:
        datas=json.load(f)
        result=dict()
        for i in range(len(datas["timelineObjects"])):
            if 'activitySegment' in datas["timelineObjects"][i].keys() and 'distance' in datas["timelineObjects"][i]['activitySegment'].keys() and 'activityType' in datas["timelineObjects"][i]['activitySegment'].keys():
                jsontest0=datas["timelineObjects"][i]['activitySegment']['distance']
                jsontest1=datas["timelineObjects"][i]['activitySegment']['activityType']
                if jsontest1 not in result.keys():
                    result[jsontest1]=jsontest0
                else:
                    result[jsontest1]+=jsontest0
        
        entireCarbon=0
        tranportCarbon=0
        for i,j in result.items():
            if i=='IN_BUS':
                entireCarbon+=j*0.027
                tranportCarbon+=j*0.027
            elif i=='IN_SUBWAY':
                entireCarbon+=j*0.0015
                tranportCarbon+=j*0.0015
            elif i=='IN_PASSENGER_VEHICLE':
                entireCarbon+=j*0.210
            elif i=='IN_TRAIN':
                entireCarbon+=j*  0.020
                tranportCarbon+=j*  0.020

        if entireCarbon == 0:
            return 0
        else:
            return round(tranportCarbon/entireCarbon, 3)

def makedict():
    result=dict()
    tmp = findFiles('./')
    for i in tmp:
        result[i.replace('.json', '')] = calC2(i)
    return result

print(makedict())

