# 그래프 데이터
import montlyData
import tkinter as tk
from tkinter import messagebox
from tkinter.simpledialog import askinteger
import matplotlib.pyplot as plt  
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.font_manager as fm
from matplotlib.ticker import FuncFormatter
import json

carbonratio = []
Monthdict=montlyData.makedict()
for i in Monthdict:
    carbonratio.append(Monthdict[i][0])
month = [i for i in range(1,len(Monthdict)+1)]

# 한글 폰트 설정
font_name = fm.FontProperties(fname="C:\\Windows\\Fonts\\malgun.ttf").get_name()
plt.rcParams['font.family'] = font_name

# 사용자 정보 표시 함수
def show_user_info():
    user_info = "사용자 정보:\n이름: 이민우\n나이: 21\n직업: 대학생"  # 여기에 사용자 정보 입력
    messagebox.showinfo("사용자 정보", user_info)



# Tkinter 윈도우 생성
root = tk.Tk()
root.title("탄산 패스")

# 윈도우 크기 및 위치 설정
window_width = 800
window_height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2
root.geometry(f"{window_width}x{window_height}+{x}+{y}")

# Matplotlib figure 생성
# Matplotlib figure 생성 (두 개의 그래프)
fig1 = Figure(figsize=(6, 6), dpi=100)  # 첫 번째 그래프 크기 조정
plot1 = fig1.add_subplot(111)
plot1.plot(month, carbonratio)
plot1.set_xlabel('월')
plot1.set_ylabel('대중교통 배출량 / 전체 배출량')
plot1.set_title('월별 탄소 배출률')


# y축 범위 설정
plot1.set_ylim(0, 1)

# 그래프를 Tkinter에 추가
# 각각의 그래프를 Tkinter에 추가
canvas1 = FigureCanvasTkAgg(fig1, master=root)
canvas1.draw()
canvas1.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=1)


pay=montlyData.YearLast()
# 감면될 세금 금액을 표시하는 Label 추가
label = tk.Label(root, text=f"원래 교통비\n{pay[1]} 원\n\n 할인된 교통비\n {pay[0]}원", font=('Helvetica', 12), width=30, height=6)
label.pack(pady=(40, 10))  # 여백을 위아래로 추가하여 위젯의 크기를 조정

# 사용자 정보를 보여주는 버튼 추가
btn_user_info = tk.Button(root, text="사용자 정보", command=show_user_info, width=20, height=2)
btn_user_info.pack(pady=(10, 20))  # 여백을 위아래로 추가하여 위젯의 크기를 조정


# Tkinter 실행
root.mainloop()
