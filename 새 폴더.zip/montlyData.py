import os
import json

def findFiles(path):
    tmp = []
    for filename in os.listdir(path):
        if '.json' in filename:
            tmp.append(filename)
    return tmp

def calC2(path):
    with open(f'{path}','r',encoding='utf-8') as f:
        datas=json.load(f)
        result=dict()
        for i in range(len(datas["timelineObjects"])):
            if 'activitySegment' in datas["timelineObjects"][i].keys() and 'distance' in datas["timelineObjects"][i]['activitySegment'].keys() and 'activityType' in datas["timelineObjects"][i]['activitySegment'].keys():
                jsontest0=datas["timelineObjects"][i]['activitySegment']['distance']
                jsontest1=datas["timelineObjects"][i]['activitySegment']['activityType']
                if jsontest1 not in result.keys():
                    result[jsontest1]=jsontest0
                else:
                    result[jsontest1]+=jsontest0
        
        entireCarbon=0
        tranportCarbon=0
        for i,j in result.items():
            if i=='IN_BUS':
                entireCarbon+=j*0.027
                tranportCarbon+=j*0.027
            elif i=='IN_SUBWAY':
                entireCarbon+=j*0.0015
                tranportCarbon+=j*0.0015
            elif i=='IN_PASSENGER_VEHICLE':
                entireCarbon+=j*0.210
            elif i=='IN_TRAIN':
                entireCarbon+=j*  0.020
                tranportCarbon+=j*  0.020

        if entireCarbon==0:
            return 1,tranportCarbon
        else:
            return [round(tranportCarbon/entireCarbon,3),tranportCarbon]

def makedict():
    result=dict()
    Monthdict=['JANUARY', 'FEBRUARY', "MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"]
    tmp = findFiles('./')
    for i in Monthdict:
        for j in tmp:
            if i in j:
                result[i]=calC2(j)
    return result

def YearLast():
    resultpay=0
    originpay=0
    Monthdata=makedict().values()
    for i in Monthdata:
        if 0.2<=i[0]<=0.4:
            resultpay+=7*i[1]*0.9
            originpay+=7*i[1]
        elif 0.4<i[0]<=0.7:
            resultpay+=7*i[1]*0.8
            originpay+=7*i[1]
        elif 0.7<i[0]<=1:
            resultpay+=7*i[1]*0.75
            originpay+=7*i[1]
        else:
            resultpay+=7*i[1]
            originpay+=7*i[1]
    return round(resultpay),round(originpay)

# 그래프 그릴때 x축 makedict() 길이 참고 y축 makedict()[0] 참조

    
