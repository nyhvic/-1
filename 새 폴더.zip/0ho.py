import tkinter as tk
from tkinter import messagebox
from tkinter.simpledialog import askinteger
import matplotlib.pyplot as plt  
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.font_manager as fm
from matplotlib.ticker import FuncFormatter
import json

# 전역 변수 선언
user_payback = 0.0

# 계산
def calC2(path):
    global user_payback  # 전역 변수 사용을 위해 추가
    with open(f'{path}','r',encoding='utf-8') as f:
        datas=json.load(f)
        result=dict()
        for i in range(len(datas["timelineObjects"])):
            if 'activitySegment' in datas["timelineObjects"][i].keys() and 'distance' in datas["timelineObjects"][i]['activitySegment'].keys() and 'activityType' in datas["timelineObjects"][i]['activitySegment'].keys():
                jsontest0=datas["timelineObjects"][i]['activitySegment']['distance']
                jsontest1=datas["timelineObjects"][i]['activitySegment']['activityType']
                if jsontest1 not in result.keys():
                    result[jsontest1]=jsontest0
                else:
                    result[jsontest1]+=jsontest0
    C2=0
    c1=0
    for i,j in result.items():
        if i=='IN_BUS':
            C2+=j*0.027
            c1+=j*0.027
        elif i=='IN_SUBWAY':
            C2+=j*0.0015
            c1+=j*0.0015
        elif i=='IN_PASSENGER_VEHICLE':
            C2+=j*0.210
        elif i=='FLYING':
            C2+=j*0.150
        elif i=='IN_TRAIN':
            C2+=j*  0.020
            c1+=j*  0.020

    user_rank=""
    user_payback=0.0  # 이 부분 추가

    if C2==0:
        user_rank='Unknown'
    elif c1 / C2 >=0.9:
        user_rank="Vvip"
        user_payback= 0.4
    elif 0.9>c1 / C2>=0.75:
        user_rank="Vip"
        user_payback= 0.3
    elif 0.75>c1/C2 >=0.5:
        user_rank="Diamond"
        user_payback=0.25
    elif 0.5  >c1/C2>=0.4:
        user_rank="Platinum"
        user_payback=0.2
    elif 0.4> c1/C2>=0.3:
        user_rank="Gold"
        user_payback=0.15
    elif 0.3>c1/C2>0.2:
        user_rank="Silver"
        user_payback=0.1
    else:
        user_rank="Bronze"
        user_payback=0.01
    
    return [round(C2/1000,2), user_rank, user_payback]

def makedict(Year, MonthList):
    result=dict()
    for i in MonthList:
        result[f'{Year}.{i}']=calC2(f'.\\{Year}_{i}.json')
    return result

tmp_dict = makedict(2023, ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'])

# 감면될 세금 금액
tax_reduction = 0

# 그래프 데이터
carbon = []
rank = []
for i in tmp_dict:
    carbon.append(tmp_dict[i][0])
    rank.append(tmp_dict[i][1])
month = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

# 한글 폰트 설정
font_name = fm.FontProperties(fname="C:\\Windows\\Fonts\\malgun.ttf").get_name()
plt.rcParams['font.family'] = font_name

# 사용자 정보 표시 함수
def show_user_info():
    user_info = "사용자 정보:\n이름: 홍길동\n나이: 30\n직업: 데이터 분석가"  # 여기에 사용자 정보 입력
    messagebox.showinfo("사용자 정보", user_info)

def get_pay_amount():
    global tax_reduction
    global pay_amount
    pay_amount = askinteger("Pay Amount", "Enter Pay Amount:")
    if pay_amount is not None:
        tax_reduction = pay_amount * user_payback
        label.config(text=f"감면될 세금 금액\n{tax_reduction} 원")

# Tkinter 윈도우 생성
root = tk.Tk()
root.title("맞다이로 걸어와")

# 윈도우 크기 및 위치 설정
window_width = 800
window_height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2
root.geometry(f"{window_width}x{window_height}+{x}+{y}")

# Matplotlib figure 생성
# Matplotlib figure 생성 (두 개의 그래프)
fig1 = Figure(figsize=(6, 6), dpi=100)  # 첫 번째 그래프 크기 조정
plot1 = fig1.add_subplot(111)
plot1.plot(month, carbon)
plot1.set_xlabel('월')
plot1.set_ylabel('대중교통 배출량 / 전체 배출량')
plot1.set_title('월별 탄소 배출률')

fig2 = Figure(figsize=(6, 6), dpi=100)  # 두 번째 그래프 크기 조정
plot2 = fig2.add_subplot(111)
plot2.bar(month, rank, color='skyblue')
plot2.set_xlabel('월')
plot2.set_ylabel('티어')
plot2.set_title('월별 티어')

# y축 범위 설정
plot1.set_ylim(0, 12)

# 너무 큰 값 왜곡하여 표시
def format_fn(value, tick_number):
    if value > 20:
        return f'{value/1000:.0f}K'
    else:
        return f'{value:.0f}'

plot1.yaxis.set_major_formatter(FuncFormatter(format_fn))

# 그래프를 Tkinter에 추가
# 각각의 그래프를 Tkinter에 추가
canvas1 = FigureCanvasTkAgg(fig1, master=root)
canvas1.draw()
canvas1.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

canvas2 = FigureCanvasTkAgg(fig2, master=root)
canvas2.draw()
canvas2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

# 감면될 세금 금액을 표시하는 Label 추가
label = tk.Label(root, text=f"감면될 세금 금액\n{tax_reduction} 원", font=('Helvetica', 8), width=30, height=2)
label.pack(pady=(40, 10))  # 여백을 위아래로 추가하여 위젯의 크기를 조정

# 사용자 정보를 보여주는 버튼 추가
btn_user_info = tk.Button(root, text="사용자 정보", command=show_user_info, width=20, height=2)
btn_user_info.pack(pady=(10, 20))  # 여백을 위아래로 추가하여 위젯의 크기를 조정

# 사용자로부터 pay_amount 입력을 받는 버튼 추가
btn_get_pay_amount = tk.Button(root, text="Pay Amount 입력", command=get_pay_amount, width=20, height=2)
btn_get_pay_amount.pack(pady=(10, 20))  # 여백을 위아래로 추가하여 위젯의 크기를 조정

# Tkinter 실행
root.mainloop()
